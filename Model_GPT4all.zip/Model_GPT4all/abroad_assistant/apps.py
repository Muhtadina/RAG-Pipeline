from django.apps import AppConfig


class AbroadAssistantConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'abroad_assistant'
