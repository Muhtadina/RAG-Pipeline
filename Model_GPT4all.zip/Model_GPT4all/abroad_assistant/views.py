from django.shortcuts import render
import os
from uuid import uuid4
from dotenv import load_dotenv
from django.http import JsonResponse
from langchain_community.document_loaders import PyPDFDirectoryLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from langchain_community.llms import GPT4All
from langchain.embeddings import GPT4AllEmbeddings

# Load environment variables (if needed)
load_dotenv()

# Define paths
DATA_PATH = "data"
CHROMA_PATH = "chroma_db"

# Initialize Embeddings & Vector Store
embeddings_model = GPT4AllEmbeddings()
vector_store = Chroma(
    collection_name="asa_collection",
    embedding_function=embeddings_model,
    persist_directory=CHROMA_PATH,
)

def ingest_data():
    """Loads files, splits text, generates embeddings, and stores in ChromaDB"""
    raw_documents = []
    
    # Load PDFs
    pdf_loader = PyPDFDirectoryLoader(DATA_PATH)
    raw_documents.extend(pdf_loader.load())

    # Load text files dynamically
    for filename in os.listdir(DATA_PATH):
        if filename.endswith(".txt"):
            text_loader = TextLoader(os.path.join(DATA_PATH, filename))
            raw_documents.extend(text_loader.load())

    # Split text into chunks
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=300,
        chunk_overlap=100
    )
    chunks = text_splitter.split_documents(raw_documents)

    # Generate unique IDs
    uuids = [str(uuid4()) for _ in range(len(chunks))]

    # Store in ChromaDB (if chunks exist)
    if chunks:
        vector_store.add_documents(documents=chunks, ids=uuids)
        print("✅ Data successfully ingested into ChromaDB.")
    else:
        print("⚠️ No valid documents found for ingestion.")

# Run ingestion once
if not os.path.exists(CHROMA_PATH):
    print("🔄 Ingesting data...")
    ingest_data()

def index(request):
    """Renders the main UI"""
    return render(request, 'index.html')

def ask_question(request):
    """Handles user query and retrieves answers from stored vector database"""
    query = request.GET.get("query", "").strip()

    if not query:
        return JsonResponse({"error": "Query parameter missing"}, status=400)

    # Retrieve similar chunks
    results = vector_store.similarity_search(query, k=5)
    
    if not results:
        return JsonResponse({"response": "No relevant information found in the database."})

    # Get retrieved texts
    retrieved_texts = [doc.page_content for doc in results]

    # Load the GPT4All model
    model_path = "models/ggml-gpt4all-j-v1.3-groovy.bin"  # Ensure the correct path
    if not os.path.exists(model_path):
        return JsonResponse({"error": "LLM model file missing. Please download it."}, status=500)

    llm = GPT4All(model=model_path)
    
    # Generate response using LLM
    response = llm.predict("\n".join(retrieved_texts))

    return JsonResponse({"response": response})
