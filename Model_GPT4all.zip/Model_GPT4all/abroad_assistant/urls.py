from django.urls import path
from .views import index, ask_question

urlpatterns = [
    path('abroad_assistant/templates/', index, name='index'),  # Renders the HTML page
    path('ask/', ask_question, name='ask_question'),  # Handles API request
]
