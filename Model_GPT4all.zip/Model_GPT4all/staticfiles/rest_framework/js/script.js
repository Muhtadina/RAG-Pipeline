function askQuestion() {
    let query = document.getElementById("query").value;
    let responseBox = document.getElementById("response-box");
    let responseText = document.getElementById("response-text");

    if (!query.trim()) {
        alert("Please enter a question!");
        return;
    }

    // Show loading text
    responseBox.style.display = "block";
    responseText.innerHTML = "Thinking...";

    // Send API request
    fetch(`/ask/?query=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            responseText.innerHTML = data.response;
        })
        .catch(error => {
            responseText.innerHTML = "Error fetching response. Please try again.";
        });
}
